@echo off
REM ============================================================
REM  EREBUS - Start script (Windows)
REM  Starts the local server (and, if set up, the local Whisper
REM  speech-to-text service) and opens Erebus in the browser.
REM ============================================================

echo ============================================================
echo   EREBUS
echo ============================================================

echo [1/2] Starting Erebus server...
start "Erebus Server" cmd /k python server.py

REM Whisper is optional. If you've set up a separate virtual environment
REM for it (see README), this starts it automatically; otherwise it's
REM skipped and you can run it manually with: python whisper_mic.py
if exist "whisper_env\" (
    echo [2/2] Starting Whisper (local speech-to-text)...
    start "Erebus Whisper" cmd /k whisper_env\Scripts\python.exe whisper_mic.py
) else (
    echo [2/2] Whisper not set up ^(no whisper_env folder^) - skipping.
    echo        See README.md if you want local, offline speech recognition.
)

echo.
echo Erebus is starting. The interface will open automatically in Chrome.
echo Close this window's server/whisper terminals to stop Erebus.
